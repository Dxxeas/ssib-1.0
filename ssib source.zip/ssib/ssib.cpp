﻿#include <windows.h>
#include <thread>
#include <chrono>
#include <cstdlib> // Для функции rand()
#include <atomic>   // Для атомарных переменных

#pragma comment(lib, "winmm.lib") // Подключаем библиотеку для PlaySound

// Глобальная переменная для отслеживания состояния мыши
std::atomic<bool> mouseMoving(true);

// Функция для показа всплывающего окна с заданным заголовком и сообщением
int ShowMessageBox(const char* title, const char* message) {
	return MessageBoxA(NULL, message, title, MB_YESNO | MB_ICONWARNING);
}

// Функция для воспроизведения музыки
void PlayMusic(const char* filePath) {
	PlaySoundA(filePath, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP); // Воспроизведение музыки бесконечно
}

// Функция для создания эффекта плывущего экрана
void CreateWaveEffect() {
	HWND hwnd = GetDesktopWindow();
	HDC hdc = GetDC(hwnd);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);

	// Создание памяти для копии экрана
	HDC memDC = CreateCompatibleDC(hdc);
	HBITMAP hbmMem = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
	HBITMAP hbmOld = (HBITMAP)SelectObject(memDC, hbmMem);

	// Бесконечный цикл для создания эффекта
	while (true) {
		// Копирование всего экрана в память
		BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);
		// Применение эффекта плавного движения
		for (int y = 0; y < screenHeight; y += 10) {
			BitBlt(hdc, rand() % 10 - 5, y, screenWidth, 10, memDC, 0, y, SRCCOPY);
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	}

	// Очистка ресурсов (никогда не достигнет этого места из-за бесконечного цикла)
	SelectObject(memDC, hbmOld);
	DeleteObject(hbmMem);
	DeleteDC(memDC);
	ReleaseDC(hwnd, hdc);
}

// Функция для телепортации курсора в разные места экрана
void TeleportCursor() {
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	POINT lastPos = { 0, 0 };
	bool cursorPreviouslyMoving = false;
	const int teleportInterval = 10; // Интервал между телепортациями в миллисекундах
	const int movementThreshold = 10; // Порог для определения движения

	while (true) {
		POINT currentPos;
		GetCursorPos(&currentPos);

		// Проверка, перемещается ли мышь
		if (abs(currentPos.x - lastPos.x) > movementThreshold || abs(currentPos.y - lastPos.y) > movementThreshold) {
			mouseMoving = true;
			cursorPreviouslyMoving = true;
		}
		else {
			mouseMoving = false;
			if (!cursorPreviouslyMoving) {
				// Телепортируем курсор в случайное место экрана
				SetCursorPos(rand() % screenWidth, rand() % screenHeight);
			}
		}

		lastPos = currentPos;
		cursorPreviouslyMoving = mouseMoving;
		std::this_thread::sleep_for(std::chrono::milliseconds(teleportInterval));
	}
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	// Первое окно предупреждения
	if (ShowMessageBox("ssib.exe", "Run Malware?") == IDYES) {
		// Второе окно предупреждения
		if (ShowMessageBox("ssib.exe (LAST WARNING)", "Are you sure?") == IDYES) {
			// Ожидание перед началом эффектов
			std::this_thread::sleep_for(std::chrono::seconds(4));

			// Запуск эффектов в отдельных потоках
			std::thread waveEffectThread(CreateWaveEffect);
			std::thread cursorTeleportThread(TeleportCursor);
			std::thread musicThread(PlayMusic, "C:\\Users\\Dxxeas\\source\\repos\\ssib\\ssib\\music.wav");

			// Ждем, пока эффекты не завершатся (в данном случае, это бесконечный цикл)
			waveEffectThread.join();
			cursorTeleportThread.join();
			musicThread.join();
		}
	}
	return 0;
}
